//
//  AppDelegate.h
//  Eu95mPaaS
//
//  Created by 冯冠华 on 2024/4/17.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

