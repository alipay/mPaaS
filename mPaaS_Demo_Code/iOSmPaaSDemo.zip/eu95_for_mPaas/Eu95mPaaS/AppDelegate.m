//
//  AppDelegate.m
//  Eu95mPaaS
//
//  Created by 冯冠华 on 2024/4/17.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

@synthesize window = _window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    return YES;
}

@end
