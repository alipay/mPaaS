//
//  MP_AnalysisViewController.h
//  mPaas_Poc_Demo
//
//  Created by wyy on 2021/7/9.
//

#import <APMobileFramework/APMobileFramework.h>

NS_ASSUME_NONNULL_BEGIN

@interface MP_AnalysisViewController : DTViewController

@end

NS_ASSUME_NONNULL_END
