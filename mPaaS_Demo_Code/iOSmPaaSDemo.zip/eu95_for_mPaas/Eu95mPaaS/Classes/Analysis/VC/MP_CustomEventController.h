//
//  MP_CustomEventController.h
//  mPaas_Poc_Demo
//
//  Created by wyy on 2021/7/17.
//

#import <APMobileFramework/APMobileFramework.h>

NS_ASSUME_NONNULL_BEGIN

@interface MP_CustomEventController : DTViewController

@end

NS_ASSUME_NONNULL_END
