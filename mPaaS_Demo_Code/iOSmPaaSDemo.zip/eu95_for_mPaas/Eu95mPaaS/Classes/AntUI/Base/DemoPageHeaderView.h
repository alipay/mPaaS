//
//  DemoPageHeaderView.h
//  AntUI
//
//  Created by 莜阳 on 2017/8/15.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#define DemoHeaderViewMarginBottom  45


@interface DemoPageHeaderView : UIView

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIView *lineView;

@end
