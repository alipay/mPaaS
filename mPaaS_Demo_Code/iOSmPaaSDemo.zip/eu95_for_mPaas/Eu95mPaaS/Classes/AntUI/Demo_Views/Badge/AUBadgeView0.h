#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_BadgeView_AUBadgeView//程序自动生成
//
//  AUBadgeView0.h
//  AntUI
//
//  Created by jinzhidong on 2018/3/7.
//  Copyright © 2018年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AUBadgeView0 : UIView

/**
 设置自定义红点图片
 
 @param customBadgeImage 自定义红点图片
 */
- (void)setcustomBadgeImage:(UIImage *)customBadgeImage;

- (void)drawBadgeStyle:(NSString *)style;

@end

#endif//程序自动生成
