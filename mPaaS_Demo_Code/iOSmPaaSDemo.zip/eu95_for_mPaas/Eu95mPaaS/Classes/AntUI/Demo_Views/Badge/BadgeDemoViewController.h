//
//  BadgeDemoViewController.h
//  AntUI
//
//  Created by zhaolei on 2017/8/31.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import "DemoBaseViewController.h"

@interface BadgeDemoViewController : DemoBaseViewController

@end
