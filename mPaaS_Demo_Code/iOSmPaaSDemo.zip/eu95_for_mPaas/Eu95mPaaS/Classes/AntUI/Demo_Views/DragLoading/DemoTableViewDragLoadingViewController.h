//
//  APRefreshTableViewController.h
//  UIDemo
//
//  Created by  songdh on 14-4-18.
//  Copyright (c) 2014年 Alipay. All rights reserved.
//

//#import "AUPullLoadingView.h"
//#import "AUDragLoadingView.h"

@interface DemoTableViewDragLoadingViewController : UIViewController<AURefreshLoadingViewDelegate,UITableViewDataSource,UITableViewDelegate>

@end
