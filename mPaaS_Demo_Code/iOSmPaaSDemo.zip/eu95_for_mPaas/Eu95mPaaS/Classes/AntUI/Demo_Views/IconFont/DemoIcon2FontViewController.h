//
//  DemoIcon2FontViewController.h
//  AntUIDemo
//
//  Created by Wang on 2019/3/21.
//  Copyright © 2019 Alipay. All rights reserved.
//

#import <AntUI/AntUI.h>

NS_ASSUME_NONNULL_BEGIN

@interface DemoIcon2FontViewController : DemoBaseViewController

@end

NS_ASSUME_NONNULL_END
