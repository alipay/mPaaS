//
//  IconfontZoomingViewController.h
//  AntUI
//
//  Created by zhaolei on 2017/9/20.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IconfontZoomingViewController : UIViewController

@property(nonatomic,copy) NSString *iconName;
@property(nonatomic,strong) UIColor *iconColor;

@end
