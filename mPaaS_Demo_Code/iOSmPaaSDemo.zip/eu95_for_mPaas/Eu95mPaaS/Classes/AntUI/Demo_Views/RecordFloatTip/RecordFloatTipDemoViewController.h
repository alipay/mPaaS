//
//  DemoAURecordFloatTipController.h
//  AntUI
//
//  Created by 莜阳 on 17/1/19.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <AntUI/AURecordFloatTip.h>


@interface RecordFloatTipDemoViewController : DemoBaseViewController
{
    AURecordFloatTip *_tipView;
}
@end
