//
//  ResultViewController.h
//  AntUI
//
//  Created by QiXin on 2016/10/11.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultViewController : UIViewController

@end
