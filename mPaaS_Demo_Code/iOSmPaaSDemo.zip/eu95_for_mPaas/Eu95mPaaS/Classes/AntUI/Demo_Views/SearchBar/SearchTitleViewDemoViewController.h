//
//  SearchTitleViewDemoViewController.h
//  AntUI
//
//  Created by 莜阳 on 2017/8/25.
//  Copyright © 2017年 Alipay. All rights reserved.
//

@interface SearchTitleViewDemoViewController : DemoBaseViewController <AUSearchTitleViewDelegate>

@end
