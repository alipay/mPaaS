//
//  DemoVerticalTabViewController.h
//  AntUIDemo
//
//  Created by zhaolei on 2018/4/12.
//  Copyright © 2018年 Alipay. All rights reserved.
//

#import "DemoBaseViewController.h"

@interface DemoVerticalTabViewController : DemoBaseViewController

@end
