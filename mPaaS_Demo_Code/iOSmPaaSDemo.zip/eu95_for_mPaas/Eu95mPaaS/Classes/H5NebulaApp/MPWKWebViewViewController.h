//
//  MPWKWebViewViewController.h
//  Eu95mPaaS
//
//  Created by 冯冠华 on 2024/7/2.
//

#import <APMobileFramework/APMobileFramework.h>

NS_ASSUME_NONNULL_BEGIN

@interface MPWKWebViewViewController : DTViewController

@end

NS_ASSUME_NONNULL_END
