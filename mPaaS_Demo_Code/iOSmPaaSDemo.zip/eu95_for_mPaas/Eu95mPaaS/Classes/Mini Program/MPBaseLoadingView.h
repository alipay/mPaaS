//
//  MPBaseLoadingView.h
//  Eu95mPaaS
//
//  Created by 冯冠华 on 2024/5/15.
//

#import <APMobileFramework/APMobileFramework.h>

NS_ASSUME_NONNULL_BEGIN

@interface MPBaseLoadingView : APBaseLoadingView

@end

NS_ASSUME_NONNULL_END
