//
//  MPPlugin4WebView.h
//  CarLife
//
//  Created by 冯冠华 on 2024/5/29.
//  Copyright © 2024 Sunboxsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AriverNebulaSDK/NBPluginBase.h>

NS_ASSUME_NONNULL_BEGIN

@interface MPPlugin4WebView : NBPluginBase

@end

NS_ASSUME_NONNULL_END
