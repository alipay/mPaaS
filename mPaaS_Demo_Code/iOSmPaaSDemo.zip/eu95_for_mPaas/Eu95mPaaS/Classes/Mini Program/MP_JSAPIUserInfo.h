//
//  MP_JSAPIUserInfo.h
//  Eu95mPaaS
//
//  Created by 冯冠华 on 2024/6/21.
//

//#import <AriverNebulaPoseidon/AriverNebulaPoseidon.h>
#import <AriverNebulaPoseidon/NebulaPoseidon.h>

NS_ASSUME_NONNULL_BEGIN

@interface MP_JSAPIUserInfo : PSDJsApiHandler

@end

NS_ASSUME_NONNULL_END
