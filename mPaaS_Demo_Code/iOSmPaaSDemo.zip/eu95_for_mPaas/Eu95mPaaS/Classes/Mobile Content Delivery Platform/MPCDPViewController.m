//
//  MPCDPViewController.m
//  Eu95mPaaS
//
//  Created by 冯冠华 on 2024/4/19.
//

#import "MPCDPViewController.h"

@interface MPCDPViewController ()

@end

@implementation MPCDPViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}


@end
