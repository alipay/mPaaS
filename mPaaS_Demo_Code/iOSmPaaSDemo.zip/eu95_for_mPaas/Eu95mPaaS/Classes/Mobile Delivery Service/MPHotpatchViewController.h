//
//  MPHotpatchViewController.h
//  Eu95mPaaS
//
//  Created by 冯冠华 on 2024/4/18.
//

#import <APMobileFramework/APMobileFramework.h>

NS_ASSUME_NONNULL_BEGIN

@interface MPHotpatchViewController : DTViewController

@end

NS_ASSUME_NONNULL_END
