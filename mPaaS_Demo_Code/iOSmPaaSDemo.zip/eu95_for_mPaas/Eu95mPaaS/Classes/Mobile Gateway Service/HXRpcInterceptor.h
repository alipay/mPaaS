//
//  HXRpcInterceptor.h
//  Eu95mPaaS
//
//  Created by 冯冠华 on 2024/7/24.
//

#import <Foundation/Foundation.h>
#import <APMobileNetwork/DTRpcInterceptor.h>

NS_ASSUME_NONNULL_BEGIN

@interface HXRpcInterceptor : NSObject<DTRpcInterceptor>

@end

NS_ASSUME_NONNULL_END
