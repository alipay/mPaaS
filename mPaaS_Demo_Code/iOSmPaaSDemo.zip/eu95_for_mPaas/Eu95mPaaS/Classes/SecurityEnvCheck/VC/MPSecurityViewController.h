//
//  MPSecurityViewController.h
//  mPaaSSecurity_Poc_Demo
//
//  Created by 浩鲸UED on 2023/2/15.
//  Copyright © 2023 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <APMobileFramework/APMobileFramework.h>

NS_ASSUME_NONNULL_BEGIN

@interface MPSecurityViewController : DTViewController

@end

NS_ASSUME_NONNULL_END
