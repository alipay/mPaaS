//
//  MP_ShareViewController.h
//  mPaas_Poc_Demo
//
//  Created by wyy on 2021/7/5.
//

#import <APMobileFramework/APMobileFramework.h>

NS_ASSUME_NONNULL_BEGIN

@interface MP_ShareViewController : DTViewController

@end

NS_ASSUME_NONNULL_END
