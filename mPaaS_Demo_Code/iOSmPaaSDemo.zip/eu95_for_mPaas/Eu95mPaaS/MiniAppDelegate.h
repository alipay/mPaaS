//
//  MiniAppDelegate.h
//  mpaas-tinyapp-ios
//
//  Created by admin on 2024/5/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MiniAppDelegate : NSObject<DTMicroApplicationDelegate>

@end

NS_ASSUME_NONNULL_END
