//
//  MiniAppViewController.h
//  mpaas-tinyapp-ios
//
//  Created by admin on 2024/5/14.
//

#import <APMobileFramework/APMobileFramework.h>

NS_ASSUME_NONNULL_BEGIN

@interface MiniAppViewController : DTViewController

@end

NS_ASSUME_NONNULL_END
