//
//  MiniAppViewController.m
//  mpaas-tinyapp-ios
//
//  Created by admin on 2024/5/14.
//

#import "MiniAppViewController.h"

@interface MiniAppViewController ()

@end

@implementation MiniAppViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.redColor;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
