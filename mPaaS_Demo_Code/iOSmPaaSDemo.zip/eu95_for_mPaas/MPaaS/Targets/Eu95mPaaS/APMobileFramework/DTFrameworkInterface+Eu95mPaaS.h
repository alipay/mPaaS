//
//  DTFrameworkInterface+Eu95mPaaS.h
//  Eu95mPaaS
//
//  Created by fengguanhua on 2024/04/17. All rights reserved.
//

#import <APMobileFramework/DTFrameworkInterface.h>

@interface DTFrameworkInterface (Eu95mPaaS)

@end

