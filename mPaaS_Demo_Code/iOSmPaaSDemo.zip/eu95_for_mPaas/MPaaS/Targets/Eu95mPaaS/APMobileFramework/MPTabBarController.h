//
//  MPTabBarController.h

#import <UIKit/UIKit.h>

@interface MPTabBarController : UITabBarController <UITabBarControllerDelegate>

@end
