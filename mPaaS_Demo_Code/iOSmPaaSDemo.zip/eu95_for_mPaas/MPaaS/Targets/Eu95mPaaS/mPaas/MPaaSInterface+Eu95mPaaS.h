//
//  MPaaSInterface+Eu95mPaaS.h
//  Eu95mPaaS
//
//  Created by fengguanhua on 2024/04/17. All rights reserved.
//

#import <mPaas/MPaaSInterface.h>
#import <MPSignatureAdapter/MPSignatureAdapter.h>

@interface MPaaSInterface (Eu95mPaaS)

@end

@interface MPSignatureInterface (Eu95mPaaS)

@end
